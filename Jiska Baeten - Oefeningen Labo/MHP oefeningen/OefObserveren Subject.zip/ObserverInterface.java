package hellotvxlet;

public interface ObserverInterface {

    public abstract void update(int tijd);
}
